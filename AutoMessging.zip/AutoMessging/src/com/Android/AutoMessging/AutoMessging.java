package com.Android.AutoMessging;





import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.EditText;
import android.widget.Toast;

@SuppressLint("NewApi")
public class AutoMessging extends Activity {
    /** Called when the activity is first created. */
	String  phonenumber,message="",cheak="";
	final Context context = this;
	TelephonyManager telephonyManager;
	
	private EditText EditText1;
	private Button Button1;
	private Button Button2;

    public void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
       //background image
        View lay = (View) findViewById(R.id.Photo); 
        lay.setBackgroundResource(R.drawable.background);
     
		//end
       
        
        //RadioButton creating
        
        
        final RadioButton RadioButton1 = (RadioButton)findViewById(R.id.RadioButton1);
        final RadioButton RadioButton2 = (RadioButton)findViewById(R.id.RadioButton2);
        final RadioButton RadioButton3 = (RadioButton)findViewById(R.id.RadioButton3);
        final RadioButton RadioButton4 = (RadioButton)findViewById(R.id.RadioButton4);
        final RadioButton RadioButton5 = (RadioButton)findViewById(R.id.RadioButton5);
        EditText1= (EditText)findViewById(R.id.EditText1);
        Button1= (Button)findViewById(R.id.Button1);
        Button2= (Button)findViewById(R.id.Button2);
       
      
        //poopuptextBox
        
        Button2.setOnClickListener(new OnClickListener() {
            
       		public void onClick(View v) {
       			
       			AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
       		 
    			// set title
    			alertDialogBuilder.setTitle("About me");
     
    			// set dialog message
    			alertDialogBuilder
    				.setMessage("MD. ABU MARJAN \nphone : +8801723791394 \nEmail:mdabumarjan66@gmail.com \nLevel : 3 Semister : 2 \nBs.c in TEE \nHSTU ")
    				.setCancelable(false)
    			
    				.setNegativeButton("Close",new DialogInterface.OnClickListener() {
    					public void onClick(DialogInterface dialog,int id) {
    						// if this button is clicked, just close
    						// the dialog box and do nothing
    						dialog.cancel();
    					}
    				});
     
    				// create alert dialog
    				AlertDialog alertDialog = alertDialogBuilder.create();
     
    				// show it
    	
    				alertDialog.show();
    				
    				
       			
              
       		}});
        //end
        
        
        Button1.setOnClickListener(new OnClickListener() {
            
       		public void onClick(View v) {
       			
       		    
       			message= EditText1.getText().toString();
       		    Toast.makeText(AutoMessging.this,String.valueOf( "Your message has taken"),Toast.LENGTH_LONG).show();
               EditText1.setText("");
       		 
              
       		}});
        
        
        RadioButton1.setOnClickListener(new OnClickListener() {
      
       		public void onClick(View v) {
       		    
       			message= RadioButton1.getText()+" Call you later ";
        
       		}});
        
        RadioButton2.setOnClickListener(new OnClickListener() {
       	 
       		
       		public void onClick(View v) {
       		 
       			message= RadioButton2.getText()+" Call you later ";

       		}});

        RadioButton3.setOnClickListener(new OnClickListener() {
       	 
       		
       		public void onClick(View v) {
       		 
       			message= RadioButton3.getText()+" Call you later ";

       		}});
        
        
        RadioButton4.setOnClickListener(new OnClickListener() {
       	 
       		
       		public void onClick(View v) {
       		 
       			message= RadioButton4.getText()+" Call you later ";

       		}});
        RadioButton5.setOnClickListener(new OnClickListener() {
  	 
		
		public void onClick(View v) {
		 
			message= RadioButton5.getText()+" Call you later ";

		}});
        
        
        //end
        
        
        
        
        
        // //main program start........
        BroadcastReceiver IncomingCallReceiver;
        
        IncomingCallReceiver   = new BroadcastReceiver() {

   		 
 	       String state ;
 		public void onReceive(Context context, Intent intent) {
 			// TODO Auto-generated method stub
 			
 			 telephonyManager = (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
 			Bundle bundle = intent.getExtras();
 			SmsManager sms = SmsManager.getDefault();
 			
 	        if(null == bundle)
 	                return;
 	       
 	       
 	       
 	        state = bundle.getString(TelephonyManager.EXTRA_STATE);
 	       
 	        if(state.equalsIgnoreCase(TelephonyManager.EXTRA_STATE_RINGING))
 	        {
 	               phonenumber = bundle.getString(TelephonyManager.EXTRA_INCOMING_NUMBER);
 	                       
 	               //Toast.makeText(AutoMessging.this,String.valueOf( phonenumber),Toast.LENGTH_SHORT).show();
 	               //if(cheak!=phonenumber)
 	              // {	   
 	              sms.sendTextMessage(phonenumber, null, message, null, null);
 	             message="";
 	                //cheak=phonenumber;
 	             //}
 		    
 	        }}};
 	
  IntentFilter filter= new IntentFilter("android.intent.action.PHONE_STATE");
  registerReceiver(IncomingCallReceiver, filter);  
        
  //end
    }
}