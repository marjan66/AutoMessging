package com.Android.AutoMessging;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

public class MainActivity   {
	//final Context context = this;
	
	 public void popup(){
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(null);
 
			// set title
			alertDialogBuilder.setTitle("yyygiurtueturyu");
 
			// set dialog message
			alertDialogBuilder
				.setMessage("fsafdg")
				.setCancelable(false)
				
				.setNegativeButton("No",new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog,int id) {
						// if this button is clicked, just close
						// the dialog box and do nothing
						dialog.cancel();
					}
				});
 
				// create alert dialog
				AlertDialog alertDialog = alertDialogBuilder.create();
 
				// show it
	
				alertDialog.show();
				
				
	}
}

